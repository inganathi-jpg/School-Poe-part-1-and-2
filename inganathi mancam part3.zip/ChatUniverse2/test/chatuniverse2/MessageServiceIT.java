
package chatuniverse2;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.List;

public class MessageServiceIT {

    @Before
    public void setup() {
        // Clear data before each test
        MessageService.getSentMessages().clear();
        MessageService.getMessageHashes().clear();
        MessageService.getMessageIDs().clear();

        // Add test data
        StoreMessages msg1 = new StoreMessages("0258524115", "+27838884567", "dinner is ready", 2);
        StoreMessages msg2 = new StoreMessages("0733480664", "+27827640601", "okay", 4);
        StoreMessages msg3 = new StoreMessages("0898452268", "+27827640601", "hide it", 6);

        msg1.setSeen(false);
        msg2.setSeen(false);
        msg3.setSeen(false);

        MessageService.addMessage(msg1, "sent");
        MessageService.addMessage(msg2, "sent");
        MessageService.addMessage(msg3, "sent");
    }

    @Test
    public void testSentMessagesPopulated() {
        List<StoreMessages> sent = MessageService.getSentMessages();
        assertEquals(3, sent.size());
        assertEquals("dinner is ready", sent.get(0).getContent());
    }

    @Test
    public void testLongestMessage() {
        StoreMessages longest = MessageService.findLongestMessage();
        assertEquals("dinner is ready", longest.getContent());
    }

    @Test
    public void testSearchByID() {
        StoreMessages result = MessageService.searchByID("0258524115");
        assertNotNull(result);
        assertEquals("+27838884567", result.getRecipient());
        assertEquals("dinner is ready", result.getContent());
    }

    @Test
    public void testSearchByRecipient() {
        List<StoreMessages> results = MessageService.searchByRecipient("+27827640601");
        assertEquals(2, results.size());
    }

    @Test
    public void testDeleteByHash() {
        StoreMessages message = MessageService.searchByID("0733480664");
        String hash = message.createMessageHash();
        boolean deleted = MessageService.deleteByHash(hash);
        assertTrue(deleted);
        assertNull(MessageService.searchByID("0733480664"));
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package chatuniverse2;

import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ingan
 */
public class StoreMessagesIT {
    
    public StoreMessagesIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getMessageID method, of class StoreMessages.
     */
    @Test
    public void testGetMessageID() {
        System.out.println("getMessageID");
        StoreMessages instance = null;
        String expResult = "";
        String result = instance.getMessageID();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getRecipient method, of class StoreMessages.
     */
    @Test
    public void testGetRecipient() {
        System.out.println("getRecipient");
        StoreMessages instance = null;
        String expResult = "";
        String result = instance.getRecipient();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getContent method, of class StoreMessages.
     */
    @Test
    public void testGetContent() {
        System.out.println("getContent");
        StoreMessages instance = null;
        String expResult = "";
        String result = instance.getContent();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getNumber method, of class StoreMessages.
     */
    @Test
    public void testGetNumber() {
        System.out.println("getNumber");
        StoreMessages instance = null;
        int expResult = 0;
        int result = instance.getNumber();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isSeen method, of class StoreMessages.
     */
    @Test
    public void testIsSeen() {
        System.out.println("isSeen");
        StoreMessages instance = null;
        boolean expResult = false;
        boolean result = instance.isSeen();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setSeen method, of class StoreMessages.
     */
    @Test
    public void testSetSeen() {
        System.out.println("setSeen");
        boolean seen = false;
        StoreMessages instance = null;
        instance.setSeen(seen);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getFlag method, of class StoreMessages.
     */
    @Test
    public void testGetFlag() {
        System.out.println("getFlag");
        StoreMessages instance = null;
        String expResult = "";
        String result = instance.getFlag();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setFlag method, of class StoreMessages.
     */
    @Test
    public void testSetFlag() {
        System.out.println("setFlag");
        String flag = "";
        StoreMessages instance = null;
        instance.setFlag(flag);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of createMessageHash method, of class StoreMessages.
     */
    @Test
    public void testCreateMessageHash() {
        System.out.println("createMessageHash");
        StoreMessages instance = null;
        String expResult = "";
        String result = instance.createMessageHash();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of storeMessage method, of class StoreMessages.
     */
    @Test
    public void testStoreMessage() {
        System.out.println("storeMessage");
        StoreMessages instance = null;
        instance.storeMessage();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of loadMessagesFromJSON method, of class StoreMessages.
     */
    @Test
    public void testLoadMessagesFromJSON() {
        System.out.println("loadMessagesFromJSON");
        List<StoreMessages> expResult = null;
        List<StoreMessages> result = StoreMessages.loadMessagesFromJSON();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class StoreMessages.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        StoreMessages instance = null;
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}

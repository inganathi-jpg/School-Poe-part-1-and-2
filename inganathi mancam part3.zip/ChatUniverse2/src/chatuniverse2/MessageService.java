package chatuniverse2;

import chatuniverse2.StoreMessages;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ingananthi mancam
 */
public class MessageService {

    private static List<StoreMessages> messages = new ArrayList<>();
    private static List<StoreMessages> sentMessages = new ArrayList<>();
    private static List<StoreMessages> storedMessages = new ArrayList<>();
    private static List<StoreMessages> disregardedMessages = new ArrayList<>();
    private static List<String> messageHashes = new ArrayList<>();
    private static List<String> messageIDs = new ArrayList<>();

    // Add message with flag ("sent", "stored", "disregard")
    public static void addMessage(StoreMessages msg, String flag) {
        messages.add(msg);
        messageHashes.add(msg.createMessageHash());
        messageIDs.add(msg.getMessageID());

        switch (flag.toLowerCase()) {
            case "sent":
                sentMessages.add(msg);
                break;
            case "stored":
                storedMessages.add(msg);
                break;
            case "disregard":
                disregardedMessages.add(msg);
                break;
        }
    }

    public static String printMessages() {
        if (messages.isEmpty()) return "No messages to show.";

        StringBuilder sb = new StringBuilder();
        for (StoreMessages m : messages) {
            sb.append(m.toString()).append("\n");
        }
        return sb.toString();
    }

    public static List<StoreMessages> getMessages() {
        return messages;
    }

    public static void displaySenderRecipient() {
        for (StoreMessages m : sentMessages) {
            System.out.println("Sender: You | Recipient: " + m.getRecipient());
        }
    }

    public static StoreMessages findLongestMessage() {
        StoreMessages longest = null;
        for (StoreMessages m : sentMessages) {
            if (longest == null || m.getContent().length() > longest.getContent().length()) {
                longest = m;
            }
        }
        return longest;
    }

    public static StoreMessages searchByID(String id) {
        for (StoreMessages m : messages) {
            if (m.getMessageID().equals(id)) return m;
        }
        return null;
    }

    public static List<StoreMessages> searchByRecipient(String recipient) {
        List<StoreMessages> result = new ArrayList<>();
        for (StoreMessages m : sentMessages) {
            if (m.getRecipient().equalsIgnoreCase(recipient)) {
                result.add(m);
            }
        }
        for (StoreMessages m : storedMessages) {
            if (m.getRecipient().equalsIgnoreCase(recipient)) {
                result.add(m);
            }
        }
        return result;
    }

    public static boolean deleteByHash(String hash) {
        StoreMessages toRemove = null;
        for (StoreMessages m : messages) {
            if (m.createMessageHash().equals(hash)) {
                toRemove = m;
                break;
            }
        }
        if (toRemove != null) {
            messages.remove(toRemove);
            messageHashes.remove(hash);
            sentMessages.remove(toRemove);
            storedMessages.remove(toRemove);
            disregardedMessages.remove(toRemove);
            return true;
        }
        return false;
    }

    public static void displayReport() {
    if (sentMessages.isEmpty()) {
        System.out.println("No sent messages to report.");
        return;
    }

    System.out.println("=== SENT MESSAGES REPORT ===");
    for (StoreMessages m : sentMessages) {
        System.out.println("Recipient: " + m.getRecipient());
        System.out.println("Message ID: " + m.getMessageID());
        System.out.println("Content: " + m.getContent());
        System.out.println("Seen: " + m.isSeen());
        System.out.println("Hash: " + m.createMessageHash());
        System.out.println("-----------------------------");
    }
}


    public static List<String> getMessageHashes() {
        return messageHashes;
    }

    public static List<String> getMessageIDs() {
        return messageIDs;
    }

    public static List<StoreMessages> getSentMessages() {
    return sentMessages;
    }

}


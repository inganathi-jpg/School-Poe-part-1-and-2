//https://github.com/inganathi-jpg?tab=repositories
package chatuniverse2;


import javax.swing.JOptionPane;
import java.io.*;

/**
 *
 * @author ingananthi mancam
 */
public class Register extends javax.swing.JFrame {
private boolean checkUsername(String username) {
    return username.length() <= 5 && username.contains("_");
}

private boolean checkPasswordComplexity(String password) {
    return password.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=]).{8,}$");
}

private boolean checkPhoneNumber(String phone) {
    return phone.startsWith("+27") && phone.length() == 12;
}
   
    public Register() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        RegSurname = new javax.swing.JTextField();
        RegUsername = new javax.swing.JTextField();
        RegPhone = new javax.swing.JTextField();
        RegName = new javax.swing.JTextField();
        RegPassword = new javax.swing.JPasswordField();
        RegConfPassword = new javax.swing.JPasswordField();
        RegChkPassword1 = new javax.swing.JCheckBox();
        RegChkPassword2 = new javax.swing.JCheckBox();
        RegButton = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        SignIN = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));

        jLabel8.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("REGISTRATION");

        jLabel9.setFont(new java.awt.Font("Script MT Bold", 3, 36)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 51, 204));
        jLabel9.setText("Chat Universe");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(274, 274, 274))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(61, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );

        jPanel2.setBackground(new java.awt.Color(102, 102, 102));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/chatuniverse2/simple chat app logo with a universe theme and a small send arrow.png"))); // NOI18N
        jLabel10.setText("jLabel10");

        jLabel11.setFont(new java.awt.Font("Script MT Bold", 3, 24)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("system of connections");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(214, 214, 214)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(156, 156, 156)
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(181, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(158, 158, 158)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel11)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setForeground(new java.awt.Color(0, 0, 204));

        jLabel1.setText("Name");

        jLabel2.setText("Surname");

        jLabel3.setText("Username");

        jLabel4.setText("Password");

        jLabel5.setText("Phone (+27)");

        jLabel6.setText("Confirm Password");

        RegSurname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegSurnameActionPerformed(evt);
            }
        });

        RegUsername.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegUsernameActionPerformed(evt);
            }
        });

        RegPhone.setText("+27");
        RegPhone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegPhoneActionPerformed(evt);
            }
        });

        RegName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegNameActionPerformed(evt);
            }
        });

        RegPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegPasswordActionPerformed(evt);
            }
        });

        RegConfPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegConfPasswordActionPerformed(evt);
            }
        });

        RegChkPassword1.setForeground(new java.awt.Color(0, 102, 255));
        RegChkPassword1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegChkPassword1ActionPerformed(evt);
            }
        });

        RegChkPassword2.setForeground(new java.awt.Color(0, 102, 255));
        RegChkPassword2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegChkPassword2ActionPerformed(evt);
            }
        });

        RegButton.setText("REGISTER");
        RegButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegButtonActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(204, 204, 204));
        jLabel7.setText("SIGN UP");

        jLabel12.setForeground(new java.awt.Color(0, 153, 204));
        jLabel12.setText("You already have an account?");

        SignIN.setForeground(new java.awt.Color(0, 102, 204));
        SignIN.setText("Go To Login Page");
        SignIN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SignINActionPerformed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Nirmala UI Semilight", 0, 10)); // NOI18N
        jLabel13.setText("(username should contain 5 or less characters and contain an underscore(_).)");

        jLabel14.setFont(new java.awt.Font("Nirmala UI Semilight", 0, 10)); // NOI18N
        jLabel14.setText("(phone number should contain international code(+27).)");

        jLabel15.setFont(new java.awt.Font("Nirmala UI Semilight", 0, 10)); // NOI18N
        jLabel15.setText("(Password should contain 8 characters, have at least one capital letter and a special character)");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(RegConfPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(SignIN)
                            .addComponent(RegButton))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(RegChkPassword2)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(32, 32, 32))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14)
                    .addComponent(RegPhone, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(RegUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13)
                    .addComponent(RegSurname, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(RegPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(RegChkPassword1))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(RegName, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel7)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(RegName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(31, 31, 31)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(RegSurname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addComponent(jLabel13)
                .addGap(3, 3, 3)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(RegUsername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(RegPhone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(18, 18, 18)
                .addComponent(jLabel15)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(RegPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel4))
                    .addComponent(RegChkPassword1, javax.swing.GroupLayout.Alignment.LEADING))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(RegConfPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel6))
                    .addComponent(RegChkPassword2))
                .addGap(27, 27, 27)
                .addComponent(RegButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SignIN)
                    .addComponent(jLabel12))
                .addContainerGap(68, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void RegNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegNameActionPerformed
String name = RegName.getText().trim();

if (name.isEmpty()){
JOptionPane.showMessageDialog(this, "fill in your name", "invalid", JOptionPane.ERROR_MESSAGE);

    }//GEN-LAST:event_RegNameActionPerformed
    }
    private void RegButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegButtonActionPerformed

    String name = RegName.getText();
    String surname = RegSurname.getText();
    String username = RegUsername.getText();
    String phone = RegPhone.getText();
    String password = new String(RegPassword.getPassword());
    String confirmPassword = new String(RegConfPassword.getPassword());

    if (!checkUsername(username)) {
        JOptionPane.showMessageDialog(this, "Username must be ≤ 5 characters and contain '_'.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    if (!checkPhoneNumber(phone)) {
        JOptionPane.showMessageDialog(this, "Invalid phone number! Must start with +27 and be 12 characters long.", "Error", JOptionPane.ERROR_MESSAGE);
        return; // REFRENCE:( Microsoft 2025), Microsoft Copilot [AI assistant software], Microsoft, accessed 13 April 2025, https://www.microsoft.com
        
        
         
    }
    if (!checkPasswordComplexity(password)) {
        JOptionPane.showMessageDialog(this, "Password must have 8 characters, an uppercase letter, a number, and a special character.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    if (!password.equals(confirmPassword)) {
        JOptionPane.showMessageDialog(this, "Passwords do not match!", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Check if the username already exists
    File usersFile = new File("users.txt");
    boolean isUserRegistered = false;
    try (BufferedReader reader = new BufferedReader(new FileReader(usersFile))) {
        String line;
        while ((line = reader.readLine()) != null) {
            String[] userDetails = line.split(",");
            String existingUsername = userDetails[2];
            if (existingUsername.equals(username)) {
                isUserRegistered = true;
                break;
            }
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error reading user data.", "Error", JOptionPane.ERROR_MESSAGE);
    }

    if (isUserRegistered) {
        JOptionPane.showMessageDialog(this, "User already exists! Redirecting to login screen.");
        new Login().setVisible(true); // Redirect to login
        this.dispose();
        return;
    }

    // Write new user to the file
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(usersFile, true))) { // Append mode
        writer.write(name + "," + surname + "," + username + "," + phone + "," + password);
        writer.newLine();
        JOptionPane.showMessageDialog(this, "Registration successful! Redirecting to login screen.");
        new Login().setVisible(true); // Redirect to login
        this.dispose();
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error saving user data.", "Error", JOptionPane.ERROR_MESSAGE);
  
    }//GEN-LAST:event_RegButtonActionPerformed
    JOptionPane.showMessageDialog(this, "Welcome Registration successful! Redirecting to login screen...");
        this.dispose(); 
        Login.main(null); 
    }

    private void RegSurnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegSurnameActionPerformed
       String surname = RegSurname.getText().trim();

if (surname.isEmpty()){
JOptionPane.showMessageDialog(this, "Name is required", "invalid", JOptionPane.ERROR_MESSAGE);
    }                                       
    }//GEN-LAST:event_RegSurnameActionPerformed

    private void RegUsernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegUsernameActionPerformed
String username = RegUsername.getText().trim(); 

 if (username.length() > 5 || !username.contains("_")) {
            JOptionPane.showMessageDialog(this, "Username is not correctly formetted, please ensure that your username contains an underscore and is not more than 5 characters in legnth", "Error", JOptionPane.ERROR_MESSAGE);
            
        }
    }//GEN-LAST:event_RegUsernameActionPerformed

    private void RegPhoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegPhoneActionPerformed
 String phone = RegPhone.getText().trim();
 
 if(!phone.matches("^(\\+27|0)[0-9]{9}$")) // REFRENCE:  Microsoft 2025, Microsoft Copilot [AI assistant software], Microsoft, accessed 13 April 2025, https://www.microsoft.com
 {
     JOptionPane.showMessageDialog(this, "PhoneNumber must start with (+27) or 0 and contain 10 digits","Invalid", JOptionPane.ERROR_MESSAGE);
 
     
 }
    }//GEN-LAST:event_RegPhoneActionPerformed

    private void RegPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegPasswordActionPerformed
 String password = new String(RegPassword.getPassword());       
        
        if (!password.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=]).{8,}$")) {
            JOptionPane.showMessageDialog(this, "Password must have 8 characters, uppercase, number & special character.", "Error", JOptionPane.ERROR_MESSAGE);
            
        }
    }//GEN-LAST:event_RegPasswordActionPerformed

    private void RegConfPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegConfPasswordActionPerformed
   String password = new String(RegPassword.getPassword());    
   String ConfPass = new String(RegConfPassword.getPassword());         
     
   if (!password.equals(ConfPass)) {
      JOptionPane.showMessageDialog(this, "Passwords do not match!", "Error", JOptionPane.ERROR_MESSAGE);
       
        }
    }//GEN-LAST:event_RegConfPasswordActionPerformed

    private void SignINActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SignINActionPerformed
int response = JOptionPane.showConfirmDialog(this, "Are you sure you want to continue?", "Confirmation", JOptionPane.YES_NO_OPTION);

    if (response == JOptionPane.YES_OPTION) {
        new Login().setVisible(true);
        this.dispose();
    } else {
        new Register().setVisible(true);
        this.dispose();
    }


    
    }//GEN-LAST:event_SignINActionPerformed

    private void RegChkPassword1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegChkPassword1ActionPerformed
if (RegPassword.getEchoChar() == '\u0000') {
        RegPassword.setEchoChar('.'); // Hide password
    } else {
        RegPassword.setEchoChar('\u0000'); // Show password
    }
  
    }//GEN-LAST:event_RegChkPassword1ActionPerformed

    private void RegChkPassword2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegChkPassword2ActionPerformed

    if (RegConfPassword.getEchoChar() == '\u0000') {
        RegConfPassword.setEchoChar('.'); // Hide password
    } else {
        RegConfPassword.setEchoChar('\u0000'); // Show password
    }

      
           
    }//GEN-LAST:event_RegChkPassword2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Register().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton RegButton;
    private javax.swing.JCheckBox RegChkPassword1;
    private javax.swing.JCheckBox RegChkPassword2;
    private javax.swing.JPasswordField RegConfPassword;
    private javax.swing.JTextField RegName;
    private javax.swing.JPasswordField RegPassword;
    private javax.swing.JTextField RegPhone;
    private javax.swing.JTextField RegSurname;
    private javax.swing.JTextField RegUsername;
    private javax.swing.JButton SignIN;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    // End of variables declaration//GEN-END:variables


}

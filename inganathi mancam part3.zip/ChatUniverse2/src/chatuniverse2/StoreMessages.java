//REFERENCE: OpenAI, 2025. ChatGPT (May 2025 version). [online] Available at: https://chat.openai.com/ [Accessed 26 May 2025].
package chatuniverse2;

import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author ingananthi mancam
 */
public class StoreMessages {
    private String messageID;
    private String recipient;
    private String content;
    private int number;
    private boolean seen;
    private String flag;

    // Full constructor with flag
    public StoreMessages(String messageID, String recipient, String content, int number, String flag) {
        this.messageID = messageID;
        this.recipient = recipient;
        this.content = content;
        this.number = number;
        this.seen = false;
        this.flag = flag;
    }

    // Overloaded constructor (default flag = "sent")
    public StoreMessages(String messageID, String recipient, String content, int number) {
        this(messageID, recipient, content, number, "sent");
    }

    // Getters and Setters
    public String getMessageID() {
        return messageID;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getContent() {
        return content;
    }

    public int getNumber() {
        return number;
    }

    public boolean isSeen() {
        return seen;
    }

    public void setSeen(boolean seen) {
        this.seen = seen;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    // SHA-256 Hashing
    public String createMessageHash() {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            String combined = messageID + recipient + content;
            byte[] hash = md.digest(combined.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) hexString.append(String.format("%02x", b));
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            return "Error generating hash";
        }
    }

    // Store message to JSON file
    public void storeMessage() {
        JSONObject messageObj = new JSONObject();
        messageObj.put("messageID", messageID);
        messageObj.put("recipient", recipient);
        messageObj.put("content", content);
        messageObj.put("number", number);
        messageObj.put("seen", seen);
        messageObj.put("hash", createMessageHash());
        messageObj.put("flag", flag);

        try (FileWriter file = new FileWriter("messages.json", true)) {
            file.write(messageObj.toJSONString() + System.lineSeparator());
        } catch (IOException e) {
            System.out.println("Error saving message: " + e.getMessage());
        }
    }

    // Load all messages from JSON file
    public static List<StoreMessages> loadMessagesFromJSON() {
        List<StoreMessages> loadedMessages = new ArrayList<>();
        JSONParser parser = new JSONParser();

        try (BufferedReader reader = new BufferedReader(new FileReader("messages.json"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                JSONObject obj = (JSONObject) parser.parse(line);

                String id = (String) obj.get("messageID");
                String recipient = (String) obj.get("recipient");
                String content = (String) obj.get("content");
                long num = (Long) obj.get("number");
                boolean seen = (Boolean) obj.get("seen");
                String flag = (String) obj.getOrDefault("flag", "sent");

                StoreMessages msg = new StoreMessages(id, recipient, content, (int) num, flag);
                msg.setSeen(seen);

                loadedMessages.add(msg);
            }
        } catch (IOException | ParseException e) {
            System.out.println("Error loading messages: " + e.getMessage());
        }

        return loadedMessages;
    }

    @Override
    public String toString() {
        return "Message #" + number +
                "\nTo: " + recipient +
                "\nContent: " + content +
                "\nID: " + messageID +
                "\nSeen: " + (seen ? "Yes" : "Not seen") +
                "\nType: " + flag +
                "\nHash: " + createMessageHash();
    }
}
